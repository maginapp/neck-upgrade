import{M as S}from"./events-C4xylofM.js";chrome.runtime.onMessage.addListener(e=>{e.type,S.SETTINGS_OPEN_STATUS});
